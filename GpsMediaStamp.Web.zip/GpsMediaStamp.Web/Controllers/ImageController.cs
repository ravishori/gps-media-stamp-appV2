﻿using GpsMediaStamp.Web.Models;
using GpsMediaStamp.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace GpsMediaStamp.Web.Controllers
{
    [ApiController]
    [Route("api/image")]
    public class ImageController : ControllerBase
    {
        private readonly IFileStorageService _fileStorage;
        private readonly IImageStampService _imageStamp;
        private readonly IHashService _hashService;
        private readonly IQrCodeService _qrService;
        private readonly ISigningService _signingService;
        private readonly ILogger<ImageController> _logger;

        private const long MaxFileSize = 20 * 1024 * 1024; // 20MB

        private readonly string[] AllowedImageExtensions =
        {
            ".jpg", ".jpeg", ".png"
        };

        public ImageController(
            IFileStorageService fileStorage,
            IImageStampService imageStamp,
            IHashService hashService,
            ISigningService signingService,
            IQrCodeService qrService,
            ILogger<ImageController> logger)
        {
            _fileStorage = fileStorage;
            _imageStamp = imageStamp;
            _hashService = hashService;
            _signingService = signingService;
            _qrService = qrService;
            _logger = logger;
        }

        [HttpPost("upload")]
        [Consumes("multipart/form-data")]
        [RequestSizeLimit(MaxFileSize)]
        public async Task<IActionResult> UploadImage([FromForm] UploadMediaRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (request.Video == null || request.Video.Length == 0)
                return BadRequest(new { error = "No image uploaded." });

            if (request.Video.Length > MaxFileSize)
                return BadRequest(new { error = "Image exceeds 20MB limit." });

            var extension = Path.GetExtension(request.Video.FileName).ToLowerInvariant();
            if (!AllowedImageExtensions.Contains(extension))
                return BadRequest(new
                {
                    error = "Invalid image type. Allowed: .jpg, .jpeg, .png"
                });

            _logger.LogInformation("Image upload started: {FileName}", request.Video.FileName);

            string? qrPath = null;
            string? tempStampedPath = null;

            var rawPath = await _fileStorage.SaveRawAsync(request.Video);

            var rawHash = _hashService.GenerateSha256(rawPath);

            var signature = _signingService.SignHash(rawHash);

            var visibleHash = rawHash.Substring(0, 20);

            var stampText =
                $"Lat: {request.Latitude} | Lon: {request.Longitude}\n" +
                $"{request.Timestamp.ToString("dd-MMM-yyyy HH:mm", CultureInfo.InvariantCulture)} IST\n" +
                $"SHA256: {visibleHash}...\n" +
                $"Developed By Ravi Shori";

            var qrPayload = JsonSerializer.Serialize(new
            {
                hash = rawHash,
                signature = signature,
                algorithm = "RSA-SHA256"
            });

            qrPath = await _qrService.GenerateQrAsync(qrPayload);

            tempStampedPath = await _imageStamp.StampImageAsync(
                rawPath,
                stampText,
                qrPath);

            var finalStampedPath = await _fileStorage.SaveStampedAsync(
                tempStampedPath,
                request.Video.FileName);

            var stampedHash = _hashService.GenerateSha256(finalStampedPath);

            // Cleanup
            if (!string.IsNullOrEmpty(qrPath) && System.IO.File.Exists(qrPath))
                System.IO.File.Delete(qrPath);

            if (!string.IsNullOrEmpty(tempStampedPath) && System.IO.File.Exists(tempStampedPath))
                System.IO.File.Delete(tempStampedPath);

            _logger.LogInformation("Image upload completed: {FileName}", request.Video.FileName);

            return Ok(new UploadResponse
            {
                RawFilePath = rawPath,
                StampedFilePath = finalStampedPath,
                RawFileHash = rawHash,
                StampedFileHash = stampedHash,
                Signature = signature,
                Message = "Image stamped and digitally signed successfully."
            });
        }
    }
}