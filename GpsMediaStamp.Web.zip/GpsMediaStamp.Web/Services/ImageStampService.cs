﻿using SixLabors.Fonts;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Drawing.Processing;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Processing;
using System;
using System.IO;
using System.Threading.Tasks;

namespace GpsMediaStamp.Web.Services
{
    public class ImageStampService : IImageStampService
    {
        public async Task<string> StampImageAsync(
            string inputPath,
            string stampText,
            string qrPath)
        {
            var outputPath = Path.Combine(
                Path.GetTempPath(),
                $"{Guid.NewGuid()}.jpg");

            using var image = await Image.LoadAsync<Rgba32>(inputPath);
            using var qrImage = await Image.LoadAsync<Rgba32>(qrPath);

            int width = image.Width;
            int height = image.Height;

            // 🔹 Create bottom strip
            int stripHeight = height / 6;

            image.Mutate(ctx =>
            {
                // Semi-transparent black strip
                ctx.Fill(
                    Color.Black.WithAlpha(0.7f),
                    new Rectangle(0, height - stripHeight, width, stripHeight)
                );
            });

            // 🔹 Load font
            var fontCollection = new FontCollection();
            var font = SystemFonts.CreateFont("Arial", height / 40);

            // 🔹 Draw text
            image.Mutate(ctx =>
            {
                ctx.DrawText(
                    stampText,
                    font,
                    Color.White,
                    new PointF(width * 0.02f, height - stripHeight + 20)
                );
            });

            // 🔹 Resize QR
            int qrSize = height / 6;

            qrImage.Mutate(x => x.Resize(qrSize, qrSize));

            // 🔹 Draw QR at bottom-right
            image.Mutate(ctx =>
            {
                ctx.DrawImage(
                    qrImage,
                    new Point(width - qrSize - 20, height - qrSize - 20),
                    1f
                );
            });

            await image.SaveAsync(outputPath);

            return outputPath;
        }
    }
}