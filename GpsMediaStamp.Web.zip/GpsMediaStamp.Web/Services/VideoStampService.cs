using GpsMediaStamp.Web.Models;
using Microsoft.Extensions.Options;
using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace GpsMediaStamp.Web.Services
{
    public class VideoStampService : IVideoStampService
    {
        private readonly FfmpegOptions _options;

        public VideoStampService(IOptions<FfmpegOptions> options)
        {
            _options = options.Value;
        }

        public async Task<string> StampVideoAsync(string inputPath, string stampText, string? qrImagePath = null)
        {
            if (!File.Exists(inputPath))
                throw new FileNotFoundException("Input video not found.");

            var outputPath = Path.Combine(
                Path.GetDirectoryName(inputPath)!,
                $"{Guid.NewGuid()}_stamped.mp4"
            );

            stampText = EscapeText(stampText);

            var filter = BuildFilter(stampText, qrImagePath);

            var inputArgs = qrImagePath != null
                ? $"-i \"{inputPath}\" -i \"{qrImagePath}\" "
                : $"-i \"{inputPath}\" ";

            var ffmpegArgs =
                inputArgs +
                $"-filter_complex \"{filter}\" " +
                "-c:v libx264 -preset fast -crf 20 " +
                "-profile:v high -level 4.2 " +
                "-pix_fmt yuv420p " +
                "-c:a aac -b:a 128k " +
                $"\"{outputPath}\" -y";

            await RunFfmpegAsync(ffmpegArgs);

            return outputPath;
        }

        private string BuildFilter(string stampText, string? qrImagePath)
        {
            var baseVideo = "[0:v]";

            var strip =
                $"{baseVideo}drawbox=x=0:y=h-(h/6):w=iw:h=h/6:color=black@0.75:t=fill," +
                $"drawtext=text='{stampText}':fontcolor=white:fontsize=h/25:" +
                "line_spacing=h/120:x=(w-text_w)/2:y=h-(h/6)+(h/18)";

            if (_options.EnableCenterWatermark)
            {
                strip +=
                    $",drawtext=text='{stampText}':fontcolor=white@0.65:" +
                    "fontsize=h/28:x=(w-text_w)/2:y=(h-text_h)/2:" +
                    $"enable='mod(t,{_options.RepeatIntervalSeconds})<{_options.RepeatDurationSeconds}'";
            }

            if (qrImagePath != null)
            {
                strip += "[v0];[v0][1:v]overlay=W-w-20:H-h-20";
            }

            return strip;
        }

        private static string EscapeText(string text)
        {
            return text
                .Replace(":", "\\:")
                .Replace("'", "\\'")
                .Replace("\n", "\\n");
        }

        private async Task RunFfmpegAsync(string arguments)
        {
            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = _options.Path,
                    Arguments = arguments,
                    RedirectStandardError = true,
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                }
            };

            process.Start();

            string errorOutput = await process.StandardError.ReadToEndAsync();
            await process.WaitForExitAsync();

            if (process.ExitCode != 0)
                throw new Exception($"FFmpeg failed: {errorOutput}");
        }
    }
}