﻿using QRCoder;
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading.Tasks;

namespace GpsMediaStamp.Web.Services
{
    public class QrCodeService : IQrCodeService
    {
        public async Task<string> GenerateQrAsync(string content)
        {
            var filePath = Path.Combine(
                Path.GetTempPath(),
                $"{Guid.NewGuid()}_qr.png");

            using var generator = new QRCodeGenerator();
            var data = generator.CreateQrCode(content, QRCodeGenerator.ECCLevel.Q);
            using var qrCode = new QRCode(data);
            using Bitmap qrImage = qrCode.GetGraphic(20);

            await Task.Run(() =>
            {
                qrImage.Save(filePath, ImageFormat.Png);
            });

            return filePath;
        }
    }
}